#!/usr/bin/env python3
"""Token usage DB query tool.

Usage:
    python3 scripts/query.py latest [N]          # last N records (default 10)
    python3 scripts/query.py session <prefix>     # by session prefix
    python3 scripts/query.py model <name>         # by model name
    python3 scripts/query.py date <from> [to]     # by date range
    python3 scripts/query.py summary [--today|<date>]  # daily summary
    python3 scripts/query.py raw <N>              # last N raw_usage
    python3 scripts/query.py raw --id <id>        # raw_usage by ID
    python3 scripts/query.py delete --session <prefix> [--force]
    python3 scripts/query.py delete --before <date> [--force]
    python3 scripts/query.py delete --id <id> [--force]
    python3 scripts/query.py export [--after <date>] [--all]
"""
from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

# Resolve DB path from Hermes config, fallback to ~/.hermes/token-usage.db
def _resolve_db_path() -> Path:
    hermes_home = os.environ.get("HERMES_HOME", "")
    config_path = Path(hermes_home) / "config.yaml" if hermes_home else None
    data_dir = None
    if config_path and config_path.exists():
        try:
            import yaml
            with open(config_path) as fh:
                config = yaml.safe_load(fh) or {}
            obs = config.get("observability", {})
            data_dir = (
                obs.get("token-consumption-tracker", {}).get("data_dir")
                or obs.get("data_dir")
            )
        except Exception:
            pass
    if not data_dir:
        data_dir = "~/.hermes"
    return Path(data_dir).expanduser() / "token-usage.db"

_DB = _resolve_db_path()


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(str(_DB))
    conn.row_factory = sqlite3.Row
    return conn


# ---- latest -----------------------------------------------------------------


def cmd_latest(args: argparse.Namespace) -> None:
    n = int(args.N) if args.N else 10
    conn = _conn()
    cur = conn.execute(
        "SELECT * FROM token_usage ORDER BY id DESC LIMIT ?", (n,)
    )
    rows = cur.fetchall()
    conn.close()
    _print_table(rows)


# ---- by session


def cmd_session(args: argparse.Namespace) -> None:
    conn = _conn()
    cur = conn.execute(
        "SELECT * FROM token_usage WHERE session_id LIKE ? ORDER BY id DESC LIMIT 50",
        (f"{args.prefix}%",),
    )
    rows = cur.fetchall()
    conn.close()
    _print_table(rows)


# ---- by model


def cmd_model(args: argparse.Namespace) -> None:
    conn = _conn()
    cur = conn.execute(
        "SELECT * FROM token_usage WHERE model LIKE ? ORDER BY id DESC LIMIT 50",
        (f"%{args.name}%",),
    )
    rows = cur.fetchall()
    conn.close()
    _print_table(rows)


# ---- by date


def cmd_date(args: argparse.Namespace) -> None:
    date_from = args.from_date
    date_to = args.to_date if args.to_date else date_from
    conn = _conn()
    cur = conn.execute(
        "SELECT * FROM token_usage WHERE created_at >= ? AND created_at <= ? ORDER BY id DESC LIMIT 100",
        (f"{date_from} 00:00:00", f"{date_to} 23:59:59"),
    )
    rows = cur.fetchall()
    conn.close()
    _print_table(rows)


# ---- summary


def cmd_summary(args: argparse.Namespace) -> None:
    if args.today:
        date_str = datetime.now().strftime("%Y-%m-%d")
    elif args.date:
        date_str = args.date
    else:
        date_str = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

    conn = _conn()
    c = conn.execute(
        "SELECT COUNT(*), COALESCE(SUM(prompt_tokens),0), COALESCE(SUM(completion_tokens),0), "
        "COALESCE(SUM(total_tokens),0), COALESCE(SUM(cache_read_tokens),0), COALESCE(SUM(cache_write_tokens),0) "
        "FROM token_usage WHERE created_at >= ? AND created_at < ?",
        (f"{date_str} 00:00:00", f"{date_str} 23:59:59"),
    )
    cnt, inp, out, tot, cache_r, cache_w = c.fetchone()
    actual_input = inp - cache_r - cache_w

    print(f"# Summary — {date_str}")
    print(f"Requests:      {cnt}")
    print(f"Input (New):   {actual_input:,}")
    print(f"Cache Read:    {cache_r:,}")
    if cache_w:
        print(f"Cache Write:   {cache_w:,}")
    print(f"Input (Total): {inp:,}")
    print(f"Output:        {out:,}")
    print(f"Total:         {tot:,}")
    if cnt:
        print(f"Avg/Request:   {tot // cnt:,}")
    print()

    # by model
    c = conn.execute(
        "SELECT model, COUNT(*), SUM(prompt_tokens), SUM(completion_tokens), SUM(total_tokens),"
        "COALESCE(SUM(cache_read_tokens),0), COALESCE(SUM(cache_write_tokens),0), ROUND(AVG(api_duration),2) "
        "FROM token_usage WHERE created_at >= ? AND created_at < ? "
        "GROUP BY model ORDER BY SUM(total_tokens) DESC",
        (f"{date_str} 00:00:00", f"{date_str} 23:59:59"),
    )
    rows = c.fetchall()
    if rows:
        print(f"{'Model':<25}  {'Req':>4}  {'Input':>10}  {'Out':>6}  {'CacheR':>8}  {'CacheW':>8}  {'Total':>10}  {'Avg(s)':>6}")
        print("-" * 90)
        for r in rows:
            print(f"{r[0]:<25}  {r[1]:>4}  {r[2]:>10,}  {r[3]:>6,}  {r[5]:>8,}  {r[6]:>8,}  {r[4]:>10,}  {r[7]:>6}")

    # by workspace
    c = conn.execute(
        "SELECT workspace, COUNT(*), SUM(prompt_tokens), SUM(completion_tokens), SUM(total_tokens) "
        "FROM token_usage WHERE created_at >= ? AND created_at < ? "
        "GROUP BY workspace ORDER BY SUM(total_tokens) DESC",
        (f"{date_str} 00:00:00", f"{date_str} 23:59:59"),
    )
    ws_rows = c.fetchall()
    if ws_rows and len(ws_rows) > 1:
        print()
        print(f"{'Workspace':<12}  {'Req':>4}  {'Input':>10}  {'Out':>6}  {'Total':>10}")
        print("-" * 52)
        for r in ws_rows:
            print(f"{(r[0] or '-'):<12}  {r[1]:>4}  {r[2]:>10,}  {r[3]:>6,}  {r[4]:>10,}")
    conn.close()


# ---- raw_usage


def cmd_raw(args: argparse.Namespace) -> None:
    conn = _conn()
    if args.id:
        cur = conn.execute("SELECT id, created_at, raw_usage FROM token_usage WHERE id = ?", (args.id,))
    else:
        n = int(args.N) if args.N else 5
        cur = conn.execute("SELECT id, created_at, raw_usage FROM token_usage ORDER BY id DESC LIMIT ?", (n,))
    rows = cur.fetchall()
    conn.close()

    if not rows:
        print("(no records)")
        return

    for r in rows:
        print(f"--- ID={r['id']}  {r['created_at']} ---")
        raw = r["raw_usage"]
        if raw:
            try:
                parsed = json.loads(raw)
                print(json.dumps(parsed, ensure_ascii=False, indent=2))
            except json.JSONDecodeError:
                print(raw)
        else:
            print("(not recorded)")
        print()


# ---- delete


def cmd_delete(args: argparse.Namespace) -> None:
    conn = _conn()

    where_clauses: list[str] = []
    params: list = []

    if args.session:
        where_clauses.append("session_id LIKE ?")
        params.append(f"{args.session}%")
    if args.before:
        where_clauses.append("created_at < ?")
        params.append(f"{args.before} 00:00:00")
    if args.id:
        where_clauses.append("id = ?")
        params.append(args.id)

    if not where_clauses:
        print("Error: specify at least one filter (--session / --before / --id)")
        sys.exit(1)

    where = " AND ".join(where_clauses)

    cur = conn.execute(f"SELECT COUNT(*) FROM token_usage WHERE {where}", params)
    count = cur.fetchone()[0]

    if count == 0:
        print("No matching records.")
        conn.close()
        return

    print(f"Will delete {count} record(s)")
    print(f"Filter: {' '.join(sys.argv[2:])}")

    if not args.force:
        try:
            confirm = input("Confirm deletion? (y/N): ")
        except (EOFError, OSError):
            confirm = "n"
        if confirm.lower() != "y":
            print("Cancelled.")
            conn.close()
            return

    conn.execute(f"DELETE FROM token_usage WHERE {where}", params)
    conn.commit()
    conn.close()
    print(f"Deleted {count} record(s).")


# ---- export


def cmd_export(args: argparse.Namespace) -> None:
    conn = _conn()
    if args.all:
        cur = conn.execute("SELECT * FROM token_usage ORDER BY id")
    elif args.after:
        cur = conn.execute(
            "SELECT * FROM token_usage WHERE created_at >= ? ORDER BY id",
            (f"{args.after} 00:00:00",),
        )
    else:
        print("Error: specify --after <date> or --all")
        conn.close()
        return

    for row in cur.fetchall():
        d = dict(row)
        if d.get("raw_usage"):
            try:
                d["raw_usage"] = json.loads(d["raw_usage"])
            except (json.JSONDecodeError, TypeError):
                pass
        print(json.dumps(d, ensure_ascii=False, default=str))
    conn.close()


# ---- helpers


def _print_table(rows: list[sqlite3.Row]) -> None:
    if not rows:
        print("(no records)")
        return
    print(f"{'ID':>4}  {'Time':<19}  {'Model':<25}  {'Input':>8}  {'Out':>6}  {'CacheR':>7}  {'CacheW':>7}  {'Total':>8}  {'WS':<8}  {'Worker':<12}")
    print("-" * 125)
    for r in rows:
        cache_r = r['cache_read_tokens'] or 0
        cache_w = r['cache_write_tokens'] or 0
        ws = (r['workspace'] or '')[:8] if 'workspace' in r.keys() else ''
        wkr = (r['worker'] or '')[:12] if 'worker' in r.keys() else ''
        print(f"{r['id']:>4}  {r['created_at']:<19}  {r['model']:<25}  {r['prompt_tokens']:>8,}  {r['completion_tokens']:>6,}  {cache_r:>7,}  {cache_w:>7,}  {r['total_tokens']:>8,}  {ws:<8}  {wkr:<12}")


# ---- main


def main() -> None:
    parser = argparse.ArgumentParser(description="Token usage DB query tool")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("latest", help="latest N records (default 10)")
    p.add_argument("N", nargs="?", help="count (default 10)")

    p = sub.add_parser("session", help="query by session prefix")
    p.add_argument("prefix")

    p = sub.add_parser("model", help="query by model name")
    p.add_argument("name")

    p = sub.add_parser("date", help="query by date range")
    p.add_argument("from_date")
    p.add_argument("to_date", nargs="?")

    p = sub.add_parser("summary", help="daily summary")
    p.add_argument("date", nargs="?", help="date YYYY-MM-DD")
    p.add_argument("--today", action="store_true", help="show today's summary")

    p = sub.add_parser("raw", help="view raw_usage JSON")
    p.add_argument("N", nargs="?", help="last N records (default 5)")
    p.add_argument("--id", type=int, help="record ID")

    p = sub.add_parser("delete", help="delete records")
    p.add_argument("--session", help="session prefix")
    p.add_argument("--before", help="before date (YYYY-MM-DD)")
    p.add_argument("--id", type=int, help="record ID")
    p.add_argument("--force", action="store_true", help="skip confirmation")

    p = sub.add_parser("export", help="export as JSONL")
    p.add_argument("--after", help="from date (YYYY-MM-DD)")
    p.add_argument("--all", action="store_true", help="export all records")

    args = parser.parse_args()

    dispatch = {
        "latest": cmd_latest,
        "session": cmd_session,
        "model": cmd_model,
        "date": cmd_date,
        "summary": cmd_summary,
        "raw": cmd_raw,
        "delete": cmd_delete,
        "export": cmd_export,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
